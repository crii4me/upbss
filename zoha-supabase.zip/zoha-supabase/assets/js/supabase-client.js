/* ==========================================================================
   upbss — Supabase connection
   Fill in SUPABASE_URL and SUPABASE_ANON_KEY below (Project Settings → API
   in your Supabase dashboard). Both are safe to expose in front-end code —
   the anon key only ever has the permissions granted by the RLS policies in
   supabase/schema.sql (public read on listings, public insert on leads).

   If these are left blank, the site quietly falls back to the static
   UPBSS.properties / UPBSS.sold arrays already in data.js and the contact /
   appraisal forms fall back to the old "simulate a send" behaviour — so
   nothing breaks while you're setting Supabase up.
   ========================================================================== */

window.UPBSS = window.UPBSS || {};

(function () {
  'use strict';

  var SUPABASE_URL = '';       // e.g. 'https://xxxxxxxxxxxx.supabase.co'
  var SUPABASE_ANON_KEY = '';  // the "anon / public" key, NOT the service_role key

  var UP = window.UPBSS;
  var client = null;

  if (SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase && window.supabase.createClient) {
    client = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  }

  /* UP.remote is the only thing the rest of the app talks to. Every method
     resolves gracefully (never throws) so callers don't need try/catch. */
  UP.remote = {
    isConfigured: !!client,

    /* Replace UP.properties / UP.sold with rows from Supabase if configured.
       Resolves once done (or immediately if not configured / on error) so
       boot() can just `.then()` it. */
    loadData: function () {
      if (!client) return Promise.resolve(false);

      var propsPromise = client
        .from('properties')
        .select('*')
        .order('ref', { ascending: false })
        .then(function (res) {
          if (res.error) { console.warn('Supabase properties load failed, using static data:', res.error.message); return; }
          if (res.data && res.data.length) UP.properties = res.data;
        });

      var soldPromise = client
        .from('sold_properties')
        .select('*')
        .order('ref', { ascending: false })
        .then(function (res) {
          if (res.error) { console.warn('Supabase sold_properties load failed, using static data:', res.error.message); return; }
          if (res.data && res.data.length) UP.sold = res.data;
        });

      return Promise.all([propsPromise, soldPromise]).then(function () { return true; }).catch(function () { return false; });
    },

    /* Insert a row. Returns a promise resolving to true/false so form
       handlers can show success/error without caring about Supabase. */
    insert: function (table, row) {
      if (!client) return Promise.resolve(false);
      return client.from(table).insert(row).then(function (res) {
        if (res.error) { console.warn('Supabase insert into ' + table + ' failed:', res.error.message); return false; }
        return true;
      }).catch(function () { return false; });
    }
  };
})();
